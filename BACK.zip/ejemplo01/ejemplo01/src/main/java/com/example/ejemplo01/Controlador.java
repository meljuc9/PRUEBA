package com.sinfloo.ejemplo01; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:42000", maxAge=3600)
@RestController
@RequestMapping({"/libros"})
public class Controlador {
    
    @Autowired
    LibroService service;
     
    @GetMapping
    public List<Libro>listar(){
        return service.listar();
    }
     
    @PostMapping
    public Libro agregar(@RequestBody Libro l){
        return service.add(l);
    }

    @GetMapping
    public Libro listarId(@PathVariable("id") int id){
        return service.listarId(id);
    }

    @PutMapping(path = {"/{id}"})
    public Libro editar(@RequestBody Libro l, @PathVariable("id") int id){    
      l.setId(id);
      return service.edit(l);
    }
    @DeleteMapping(path = {"/{id}"})
    public Libro delete(@PathVariable("id") int id){
        return service.delete(id);
    }
}