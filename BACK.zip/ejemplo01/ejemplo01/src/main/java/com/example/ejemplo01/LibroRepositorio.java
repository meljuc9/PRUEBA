package com.sinfloo.ejemplo01;

import java.io.Serializable;
import org.springframework.data.repository.Repository;

public interface LibroRepositorio extends Repository<Libro, Integer>{
    List<Libro>findAll();
    Libro findOne(int id);
    Libro save(Libro l);
    void delete(Libro l);
}