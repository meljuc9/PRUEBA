package com.sinfloo.ejemplo01;
import javax.persistence.*;

@Entity
@Table(name="libros")
public class Libro{
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private String nombre;
    @Column 
    private String autor;
    @Column
    private String categoria;
    @Column
    private int disponible;
    @Column
    private int reservada;

    public int getId(){
        return id;
    }

    public void setId(int id) {
        this.id = Id;
    }

    public String getNombre(){
        return nombre
    }

    public void setNombre(){
        this.nombre = nombre; 
    }

    public String getAutor(){
        return autor;
    }
    
    public void setAutor(){
        this.autor = autor; 
    }

   public String getCategoria(){
       return categoria;
    }

    public void setCategoria(){
        this.categoria = categoria; 
    }

   public String getDisponible(){
       return disponible;
    }

    public void setDisponible(){
        this.disponible = disponible; 
    }

   public String getReservada(){
       return reservada;
    }

    public void setReservada(){
        this.reservada = reservada; 
    }
}
