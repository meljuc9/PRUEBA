package com.sinfloo.ejemplo01; 

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public interface LibroServiceImp implements LibroService{
    
    @Autowired
    private LibroRepositorio repositorio;

    @Override
    public List<Libro> listar(){
        return repositorio.findAll();
    }

    @Override
    public Libro listarId(int id){
        return repositorio.findOne(id);
    }
    
    @Override
    public Libro add(Libro l){
        return repositorio.save(p);
    }

    @Override
    public Libro edit(Libro l){
        return repositorio.save(l);
    }
    
    @Override
    public Libro delete(int id){
        Libro l=repositorio.findOne(id);
        if (l!=null){
            repositorio.delete(l);
        }
        return p;
    }
}