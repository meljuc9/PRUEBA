package com.sinfloo.ejemplo01;
import java.util.List;

public interface LibroService {
    List<Libro>listar();
    Libro listarID(int id);
    Libro add(Libro l);
    Libro edit(Libro l);
    Libro delete(Libro l);
}